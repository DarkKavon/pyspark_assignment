# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['codac_tool']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'codac-tool',
    'version': '1.0.0',
    'description': 'Simple tool that takes two comma-separated datasets, joins them and filters by countries',
    'long_description': 'None',
    'author': 'Kacper Wandel',
    'author_email': 'kacperwandel@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
}


setup(**setup_kwargs)
